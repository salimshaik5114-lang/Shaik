# QR Pay App (Android + Kotlin)

Ye app user ko text/UPI ID/link daalne deti hai, **₹1 payment** (Razorpay ke through) lene ke baad
QR code generate karti hai, aur usse save/share karne deti hai.

## Kya-kya included hai
- `app/src/main/java/com/example/qrpayapp/MainActivity.kt` — poora logic (payment + QR generation)
- ZXing library — QR code banane ke liye (koi paid/external API nahi, local generation)
- Razorpay Checkout SDK — ₹1 payment lene ke liye

## Setup Steps (zaroori)

### 1. Android Studio mein open karein
- Android Studio (latest stable version, 2023.x ya naya) install karein.
- "Open" karke is poore `QRPayApp` folder ko select karein.
- Gradle sync hone dein (internet chahiye hoga, dependencies download hongi).

### 2. Razorpay account banayein
1. https://dashboard.razorpay.com/ par jaake free account banayein.
2. **Settings → API Keys** mein jaake apni **Key ID** copy karein.
   - Test mode mein key `rzp_test_...` se shuru hogi — testing ke liye use karein.
   - Live payment lene ke liye KYC complete karke live key (`rzp_live_...`) generate karein.
3. `MainActivity.kt` file mein ye line dhundhein:
   ```kotlin
   private val RAZORPAY_KEY_ID = "rzp_test_XXXXXXXXXXXX"
   ```
   Yahan apni actual Key ID daal dein.

### 3. Amount change karna ho to
`MainActivity.kt` mein:
```kotlin
private val AMOUNT_IN_PAISE = "100" // 100 paise = ₹1
```
Isko paise mein hi likhein (₹2 ke liye "200", ₹5 ke liye "500", etc.)

### 4. Build & Run
- Emulator ya real phone connect karke green ▶ Run button dabayein.
- Real device pe test karte waqt Razorpay ke liye Google Play Services + Internet chahiye.

## ⚠️ Production ke liye zaroori baatein (bahut important)

1. **Server-side verification**: Abhi ye app sirf Razorpay ke client-side "success" callback
   par bharosa karke QR generate karti hai. Iska matlab agar koi user payment cancel/fail karke
   bhi kisi tarah callback ko trigger kar de, to fraud ho sakta hai. **Production app ke liye
   aapko apna khud ka backend server (Node.js/PHP/etc.) banana chahiye** jo Razorpay
   `payment_id`, `order_id`, aur `signature` ko server par verify kare, tabhi QR unlock ho.
   Razorpay docs: https://razorpay.com/docs/payments/server-integration/

2. **KYC & Live Mode**: Test key se real paisa nahi katega. Real users se ₹1 lene ke liye
   Razorpay par business KYC complete karke live key use karni hogi.

3. **Play Store policy**: Agar ye app Play Store par publish karni hai, to Google Play ki
   payment policy check kar lein — kuch categories ke liye Google Play Billing System
   mandatory hota hai (digital goods/services ke liye), jabki physical goods/services ya
   simple utility charges ke liye third-party gateway (Razorpay/UPI) allowed hai. Apne case
   ko Play Console policy se match karke confirm kar lein:
   https://support.google.com/googleplay/android-developer/answer/9858738

4. **App icon**: Filhaal ek simple placeholder icon diya gaya hai
   (`app/src/main/res/drawable/ic_launcher.xml`). Chahen to Android Studio ke
   "Image Asset Studio" (right-click res folder → New → Image Asset) se apna khud ka
   professional icon bana sakte hain.

## Folder Structure
```
QRPayApp/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/qrpayapp/MainActivity.kt
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/ (strings, colors, themes)
│           └── drawable/ic_launcher.xml
├── build.gradle
├── settings.gradle
└── gradle.properties
```
