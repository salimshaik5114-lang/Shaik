# Add project specific ProGuard rules here.
-keep class com.razorpay.** { *; }
-dontwarn com.razorpay.**
