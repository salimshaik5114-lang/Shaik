package com.example.qrpayapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.qrpayapp.databinding.ActivityMainBinding
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import org.json.JSONObject

/**
 * MainActivity
 *
 * Flow:
 * 1. User types the text / UPI id / link they want to encode.
 * 2. User taps "₹1 Pay Karke QR Banayein".
 * 3. Razorpay Checkout opens, charges ₹1 (100 paise).
 * 4. On payment success -> QR code is generated locally using ZXing and shown.
 * 5. User can save the QR to gallery or share it.
 *
 * IMPORTANT: Replace RAZORPAY_KEY_ID below with your own Razorpay Key ID.
 * See README.md for full setup instructions (creating a Razorpay account,
 * getting keys, and — for production — verifying payments on a backend server).
 */
class MainActivity : AppCompatActivity(), PaymentResultListener {

    private lateinit var binding: ActivityMainBinding

    // TODO: Replace with your own Razorpay Key ID (get it from https://dashboard.razorpay.com/)
    private val RAZORPAY_KEY_ID = "rzp_test_XXXXXXXXXXXX"

    // Amount is in paise. 100 paise = ₹1
    private val AMOUNT_IN_PAISE = "100"

    private var pendingInputText: String = ""
    private var lastGeneratedBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Required one-time Razorpay initialization
        Checkout.preload(applicationContext)

        binding.btnGenerate.setOnClickListener {
            val text = binding.etInput.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) {
                Toast.makeText(this, "Pehle kuch text ya UPI ID / link daalein", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pendingInputText = text
            startPayment()
        }

        binding.btnSave.setOnClickListener { saveQrToGallery() }
        binding.btnShare.setOnClickListener { shareQr() }
    }

    private fun startPayment() {
        val checkout = Checkout()
        checkout.setKeyID(RAZORPAY_KEY_ID)

        try {
            val options = JSONObject()
            options.put("name", getString(R.string.app_name))
            options.put("description", getString(R.string.payment_desc))
            options.put("currency", "INR")
            options.put("amount", AMOUNT_IN_PAISE) // ₹1
            options.put("theme.color", "#1B5E20")

            // Optional prefill - uncomment and fill if you want to prefill contact/email
            // val prefill = JSONObject()
            // prefill.put("email", "customer@example.com")
            // prefill.put("contact", "9999999999")
            // options.put("prefill", prefill)

            checkout.open(this, options)
        } catch (e: Exception) {
            Toast.makeText(this, "Payment start nahi ho paya: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Called by Razorpay SDK when payment succeeds
    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        Toast.makeText(this, "Payment safal! Aapka QR ban raha hai...", Toast.LENGTH_SHORT).show()
        generateQrCode(pendingInputText)
    }

    // Called by Razorpay SDK when payment fails or is cancelled
    override fun onPaymentError(code: Int, response: String?) {
        Toast.makeText(this, "Payment fail ho gaya ya cancel hua. QR nahi banega.", Toast.LENGTH_LONG).show()
    }

    private fun generateQrCode(content: String) {
        try {
            val size = 800
            val writer = QRCodeWriter()
            val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size)
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
            for (x in 0 until size) {
                for (y in 0 until size) {
                    bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            lastGeneratedBitmap = bitmap
            binding.ivQrCode.setImageBitmap(bitmap)
            binding.ivQrCode.visibility = android.view.View.VISIBLE
            binding.layoutActions.visibility = android.view.View.VISIBLE
        } catch (e: Exception) {
            Toast.makeText(this, "QR banane mein error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveQrToGallery() {
        val bitmap = lastGeneratedBitmap ?: return
        try {
            val savedUriString = MediaStore.Images.Media.insertImage(
                contentResolver, bitmap, "qr_${System.currentTimeMillis()}", "Generated QR Code"
            )
            if (savedUriString != null) {
                Toast.makeText(this, "QR gallery mein save ho gaya", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Save nahi ho paya", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareQr() {
        val bitmap = lastGeneratedBitmap ?: return
        try {
            val path = MediaStore.Images.Media.insertImage(
                contentResolver, bitmap, "qr_share_${System.currentTimeMillis()}", null
            )
            val uri = android.net.Uri.parse(path)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "QR Share Karein"))
        } catch (e: Exception) {
            Toast.makeText(this, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
